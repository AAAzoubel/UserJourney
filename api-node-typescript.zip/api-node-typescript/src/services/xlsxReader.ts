// Importamos a biblioteca xlsx, responsável por:
// - Abrir arquivos .xlsx
// - Ler abas
// - Converter células em objetos JS
import xlsx from "xlsx";


// Interface que define o formato cru vindo da planilha.
// Cada linha da planilha vira um RawEvent.
// Isso é o que o backend espera receber
export interface RawEvent {
    sessionId: string;   // Identificador da sessão, que vai agrupar uma jornada
    utm_source: string;  // Canal clicado (facebook, google, etc.)
    createdAt: string;   // Data e hora exata daquele evento
}


// Esta função recebe um caminho para um arquivo .xlsx e devolve um array de RawEvent.
//Transforma a planilha em objetos legíveis para o backend.
export function readRawEvents(path: string): RawEvent[] {

    // 1. Lê o arquivo Excel inteiro da máquina.
    const excelFile = xlsx.readFile(path);

    // 2. Pega a primeira aba da planilha.
    const excelSheet = excelFile.Sheets[excelFile.SheetNames[0]];

    // 3. Converte a aba da planilha em uma lista de objetos JS.
    // defval: "" garante que células vazias não quebrem o código.
    const rows = xlsx.utils.sheet_to_json<any>(excelSheet, { defval: "" });


    // 4. Transformamos cada linha em um RawEvent do nosso formato.
    return rows.map(r => ({
        sessionId: String(r.sessionId),
        utm_source: String(r.utm_source),
        createdAt: String(r.createdAt),
    }));
}
