// Importamos o dayjs, que é uma biblioteca para manipular datas.
// Ela permite comparar, ordenar e formatar datas facilmente.
import dayjs from "dayjs";

// Importamos o tipo RawEvent, que representa os dados brutos vindo da planilha.
import { RawEvent } from "./xlsxReader";


// Interface que define o formato final de cada touchpoint depois do processamento.
// utm_source = canal
// createdAt = data e hora da interação
export interface Touchpoint {
    utm_source: string;
    createdAt: string;
}


// Interface completa da jornada já tratada.
export interface Journey {
    sessionId: string;         // ID da sessão: identifica a jornada de um único usuário
    touchpoints: Touchpoint[]; // lista final de pontos de contato, já filtrados e organizados
    start_at: string;          // data do primeiro evento da jornada
    end_at: string;            // data do último evento da jornada
}


// Função principal responsável por:
// 1. Agrupar eventos por sessionId
// 2. Ordenar eles por data
// 3. Remover duplicados no meio da jornada
// 4. Construir a jornada final
export function processJourneys(events: RawEvent[]): Journey[] {

    // Objeto usado para agrupar todos os eventos por sessionId.
    const group_sessionId: Record<string, RawEvent[]> = {};


    // Para cada evento bruto vindo da planilha:
    // O objetivo é separar os eventos por sessionId.
    for (const RawEvent of events) {

        // Se ainda não existe uma chave com esse sessionId, criamos uma lista vazia
        if (!group_sessionId[RawEvent.sessionId]) group_sessionId[RawEvent.sessionId] = [];

        // Adicionamos o evento dentro da sua respectiva sessão
        group_sessionId[RawEvent.sessionId].push(RawEvent);
    }


    // Aqui vamos armazenar as jornadas finais já processadas
    const journeys: Journey[] = [];


    // Agora percorremos cada sessão agrupada
    // "sessionId" é a chave, "group" é a lista de eventos daquela sessão
    for (const [sessionId, group] of Object.entries(group_sessionId)) {

        // Ordenamos os eventos pela data (createdAt)
        // Isso garante que a jornada reflita a ordem real dos acontecimentos.
        const ordered = group.sort((a, b) =>
            dayjs(a.createdAt).valueOf() - dayjs(b.createdAt).valueOf()
        );

        // Pegamos o primeiro evento (primeiro touchpoint)
        const firstEvent = ordered[0];

        // Pegamos o último evento (ultimo touchpoint)
        const lastEvent = ordered[ordered.length - 1];

        // Pegamos todos os eventos intermediários (do segundo até o penúltimo)
        const middleEvent = ordered.slice(1, -1);


        // Criamos um conjunto para armazenar canais já vistos.
        // Isso serve para evitar duplicações no meio da jornada.
        const seenChannels = new Set<string>();

        // Aqui filtramos eventos intermediários duplicados.
        const middleDuplicate = middleEvent.filter(e => {

            // Se o canal já apareceu no meio, ignoramos
            if (seenChannels.has(e.utm_source)) return false;

            // Se ainda não vimos esse canal, marcamos ele como visto
            seenChannels.add(e.utm_source);

            // E retornamos true, para deixar ele passar
            return true;
        });


        // Montamos a lista final de touchpoints da jornada:
        // 1. Primeiro evento
        // 2. Intermediários sem duplicados
        // 3. Último evento
        const finalTouchpoints: Touchpoint[] = [
            { utm_source: firstEvent.utm_source, createdAt: firstEvent.createdAt },
            ...middleDuplicate.map(e => ({
                utm_source: e.utm_source,
                createdAt: e.createdAt
            })),
            { utm_source: lastEvent.utm_source, createdAt: lastEvent.createdAt },
        ];


        // Adicionamos a jornada completa na lista final
        journeys.push({
            sessionId,
            touchpoints: finalTouchpoints,
            start_at: firstEvent.createdAt,
            end_at: lastEvent.createdAt,
        });
    }


    // Retornamos todas as jornadas processadas para serem usadas no endpoint /journeys
    return journeys;
}
