// Importa o Express, que é o framework HTTP usado
// para criar rotas, iniciar servidor e responder requisições.
import express from "express";

// Importa a função que lê o arquivo Excel e transforma em eventos brutos
import { readRawEvents } from "./services/xlsxReader";

// Importa a função que pega os eventos brutos e cria jornadas processadas
import { processJourneys } from "./services/journeyProcessing";

// Importa o CORS para permitir que o frontend acesse esta API
import cors from "cors";


// ------------------------------------------------------------
// Configuracao do Express
// ------------------------------------------------------------

const app = express(); // Cria o servidor Express

// Habilita o CORS, permitindo que *qualquer* origem acesse a API.
// Sem isso, o navegador bloqueia as requisições do React.
app.use(cors());


// ------------------------------------------------------------
// Rota principal
// ------------------------------------------------------------

// Quando o usuário acessa: http://localhost:3000/journeys
app.get("/journeys", (req, res) => {
    try {
        // 1 — Lê o arquivo XLSX com os dados brutos
        const rawData = readRawEvents("file/[Nemu] Base de dados.xlsx");

        // 2 — Processa os eventos aplicando todas as regras
        const processedJourneys = processJourneys(rawData);

        // 3 — Envia um JSON com:
        // - total de jornadas
        // - lista completa das jornadas processadas
        res.json({
            total: processedJourneys.length,
            processedJourneys
        });

    } catch (err: any) {
        // Se algo der errado,
        // retornamos erro 500 com a mensagem explicando o problema.
        res.status(500).json({ error: err.message });
    }
});


// ------------------------------------------------------------
// Subindo o a API
// ------------------------------------------------------------

// Se existir uma variável ambiente ApiEntry, usa ela.
// Senão, usa a porta padrão 3000.
const ApiEntry = process.env.ApiEntry || 3000;

// Inicia o servidor, escutando na porta definida acima.
app.listen(ApiEntry, () => {
    console.log(`API listening on http://localhost:${ApiEntry}`);
    console.log("Use /journeys to see all the journeys");
});
