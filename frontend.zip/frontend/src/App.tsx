// Front end da nossa API, servindo para apresentar os dados da forma mais agradável no navegador

// Importamos dois hooks fundamentais do React:
// - useState: armazena valores que mudam (estado do componente)
// - useEffect: executa algo automaticamente quando o componente é carregado
import { useEffect, useState } from "react";


// -----------------------------
//  Definindo as interfaces
// -----------------------------

// Interface que representa um touchpoint individual.
// Cada touchpoint é um ponto de contato do usuário com algum canal
interface Touchpoint {
  utm_source: string;   // nome do canal 
  createdAt: string;    // data em que o evento aconteceu
}

// Interface que representa uma jornada completa.
// Cada jornada possui:
// - sessionId: identificador da sessão
// - touchpoints: todos os eventos, por onde o usuario passa
// - start_at: primeiro evento (data inicial)
// - end_at: último evento (data final)
interface Journey {
  sessionId: string;
  touchpoints: Touchpoint[];
  start_at: string;
  end_at: string;
}


// -----------------------------
// Definindo cores por canal
// -----------------------------

// Lista de cores associadas a alguns canais mais comuns.
// Isso serve apenas para melhorar visualmente o front-end.
// Caso o canal não exista no objeto, usamos a cor "default".
const channelColors: Record<string, string> = {
  facebook: "blue",
  google: "red",
  instagram: "deeppink",
  organic: "green",
  default: "#90caf9" // cor padrão caso o canal não esteja mapeado
};




// -----------------------------
// Componente principal do frontend, onde ocorrem todas as acoes
// -----------------------------
function App() {

  // useState inicializa "journeys" como um array vazio.
  // Depois que buscarmos os dados no backend, esse estado será preenchido.
  const [journeys, setJourneys] = useState<Journey[]>([]);


  // useEffect roda automaticamente apenas *uma vez*, quando o componente é montado.
  // Aqui fazemos a chamada ao backend (fetch na nossa API).
  useEffect(() => {

    // Requisição GET para a API em http://localhost:3000/journeys
    fetch("http://localhost:3000/journeys")
      .then(res => res.json()) // converte a resposta para JSON
      .then(data => {
        console.log("Data received:", data); // mostra no console os dados recebidos

        // A API retorna um objeto com a propriedade "Usrjourneys".
        // Se existir, salvamos no estado. Caso não exista, deixamos array vazio.
        setJourneys(data.processedJourneys || []);
      })
      .catch(err => console.error(err)); // caso dê erro, mostramos no console
  }, []);
  // array vazio [] significa que useEffect roda apenas uma vez 




  // -----------------------------
  // Essa parte vai ser responsavel pelo que aparece na tela do front
  // -----------------------------
  return (
    <div
      style={{
        padding: "30px",
        fontFamily: "Arial, sans-serif",
        backgroundColor: "white"
      }}
    >
      <h1 style={{ color: "#2c3e50", marginBottom: "30px" }}>Jornadas</h1>


      {/* 
        Para cada jornada recebida do backend,
        criamos um card exibindo todas as informações.
      */}
      {journeys.map(journey => (
        <div
          key={journey.sessionId} // chave única exigida pelo React para listas
          style={{
            marginBottom: "30px",
            border: "1px solid #ddd",
            borderRadius: "10px",
            boxShadow: "0 2px 5px rgba(0,0,0,0.1)",
            backgroundColor: "#fff",
            padding: "20px"
          }}
        >

          {/* Exibimos dados principais da jornada */}
          <h3 style={{ marginBottom: "10px", color: "#34495e" }}>
            Sessão: {journey.sessionId}
          </h3>

          <p>
            <strong>Number of channels:</strong> {journey.touchpoints.length}
          </p>
          <p>
            <strong>Start:</strong> {journey.start_at}
          </p>
          <p>
            <strong>End:</strong> {journey.end_at}
          </p>


          {/* 
            Agora mostramos cada touchpoint individual como um card colorido.
            Cada touchpoint tem:
            - Nome do canal
            - Data
            - Cor correspondente
          */}
          <div
            style={{
              display: "flex",
              gap: "10px",
              flexWrap: "wrap",
              marginTop: "15px"
            }}
          >
            {/* Iteramos sobre os touchpoints */}
            {journey.touchpoints.map((touchpoint, position) => {

              // Pegamos a cor do canal. Se não existir, usamos default.
              const color =
                channelColors[touchpoint.utm_source.toLowerCase()] ||
                channelColors.default;


              // Retornamos cada badge com sua cor
              return (
                <div
                  key={position}
                  style={{
                    padding: "10px",
                    backgroundColor: color,
                    color: "#fff",
                    borderRadius: "6px",
                    minWidth: "120px",
                    textAlign: "center"
                  }}
                >
                  {/* Nome do canal */}
                  <strong>{touchpoint.utm_source}</strong>

                  {/* Data de criação */}
                  <div style={{ fontSize: "12px", marginTop: "4px" }}>
                    {touchpoint.createdAt}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}


// Exporta o componente para ser usado no main.tsx e renderizado no navegador
export default App;
